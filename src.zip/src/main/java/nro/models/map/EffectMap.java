package nro.models.map;

import lombok.Getter;
import lombok.Setter;

/**
 * @author Văn Tuấn - 0337766460
 */
@Setter
@Getter
public class EffectMap {
    private String key;
    private String value;
}
