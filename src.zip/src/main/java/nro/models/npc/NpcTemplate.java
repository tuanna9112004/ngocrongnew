
package nro.models.npc;


public class NpcTemplate {

    public int id;
    public String name;
    public int head;
    public int body;
    public int leg;
}
