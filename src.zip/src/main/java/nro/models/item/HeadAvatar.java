/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package nro.models.item;

/**
 *
 * @author Kitak
 */
public class HeadAvatar {

    public int headId;

    public int avatarId;

    public HeadAvatar(int headId, int avatarId) {
        this.headId = headId;
        this.avatarId = avatarId;
    }
}
