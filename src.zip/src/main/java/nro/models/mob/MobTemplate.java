/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package nro.models.mob;

/**
 *
 * @author Kitak
 */
public class MobTemplate {

    public int id;
    public byte type;
    public String name;
    public long hp;
    public byte rangeMove;
    public byte speed;
    public byte dartType;
    public byte percentDame;
    public byte percentTiemNang;
}
