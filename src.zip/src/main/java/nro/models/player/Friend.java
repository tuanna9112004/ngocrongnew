package nro.models.player;

/**
 *
 * @author Văn Tuấn - 0337766460
 * @copyright 💖 GirlkuN 💖
 *
 */
public class Friend {

    public int id;
    public String name;
    public short head;
    public short body;
    public short leg;
    public byte bag;
    public long power;
    public boolean online;

}
