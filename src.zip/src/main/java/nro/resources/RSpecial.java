/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package nro.resources;

/**
 *
 * @author Văn Tuấn - 0337766460
 */
public class RSpecial extends AbsResources {

    public RSpecial() {
        setFolder("special");
    }
}
