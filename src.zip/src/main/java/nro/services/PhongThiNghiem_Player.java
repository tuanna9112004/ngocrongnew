package nro.services;

import lombok.Getter;
import nro.models.player.Player;

/**
 *
 * @author Hoàng Việt - 0857853150
 *
 */
public class PhongThiNghiem_Player extends Player {
    @Getter
    public int idBinh;
    @Getter
    public long timeCheTao;

}
