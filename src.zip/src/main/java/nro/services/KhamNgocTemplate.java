package nro.services;

import nro.models.item.ItemOption;

/**
 *
 * @author Hoàng Việt - 0857853150
 *
 */
public class KhamNgocTemplate {

    public int level;
    public int tempId;
    public int max_value;
    public ItemOption options;
}
