package nro.services;

import java.util.ArrayList;
import nro.models.item.ItemOption;

/**
 *
 * @author Hoàng Việt - 0857853150
 *
 */
public class PhongThiNghiem_Template {

    public int tempId;
    public int quantity;
}
