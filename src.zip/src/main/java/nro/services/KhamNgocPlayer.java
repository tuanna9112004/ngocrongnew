package nro.services;

import lombok.Getter;
import nro.models.player.Player;

/**
 *
 * @author Hoàng Việt - 0857853150
 *
 */
public class KhamNgocPlayer extends Player {
    @Getter
    public int idNro;
    @Getter
    public int levelNro;

}
