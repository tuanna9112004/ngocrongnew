package nro.services;

/**
 *
 * @author Hoàng Việt - 0857853150
 *
 */
public class RuongSuuTamTemplate{

    public int id;
    public byte type;
    public int id_item;
    public int option_id;
    public int param;
}
