package nro.services;

/**
 *
 * @author Hoàng Việt - 0857853150
 *
 */
public class PhucLoiManager {

    public String tab_name;
    public int id_tab;
    public int max_tab;
    public String info_phucloi;
    public int action;
    public String tichLuy;

}
