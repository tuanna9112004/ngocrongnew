package nro.services;

import java.util.ArrayList;
import java.util.List;
import nro.models.item.Item;
import nro.models.player.Player;

/**
 *
 * @author Hoàng Việt - 0857853150
 *
 */
public class RuongSuuTamPlayer {
    public List<Item> RuongCaiTrang = new ArrayList<>();
    public List<Item> RuongPhuKien = new ArrayList<>();
    public List<Item> RuongPet = new ArrayList<>();
    public List<Item> RuongLinhThu = new ArrayList<>();
    public List<Item> RuongThuCuoi = new ArrayList<>();
}
