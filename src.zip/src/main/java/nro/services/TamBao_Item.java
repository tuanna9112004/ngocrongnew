package nro.services;

import nro.models.item.Item;

/**
 * @author Hoàng Việt - 0857853150
 */
public class TamBao_Item extends Item {
    public int id_moc;
    public int max_value;
}
