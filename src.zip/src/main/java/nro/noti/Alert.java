package nro.noti;

import nro.jdbc.DBService;
import nro.models.player.Player;
import nro.services.Service;

import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

/**
 * @author Văn Tuấn - 0337766460
 */
public class Alert {
    public String content;
}
